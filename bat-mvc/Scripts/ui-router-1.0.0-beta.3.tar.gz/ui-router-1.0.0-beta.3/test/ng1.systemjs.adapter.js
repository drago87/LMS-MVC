System.set('angular', System.newModule(window.angular));
