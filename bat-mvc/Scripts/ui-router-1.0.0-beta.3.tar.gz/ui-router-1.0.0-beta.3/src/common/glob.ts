/** @module common */ 
/** 
 * Matches state names using glob-like pattern strings.
 *
 * Globs can be used in specific APIs including:
 *
 * - [[StateService.is]]
 * - [[StateService.includes]]
 * - [[HookMatchCriteria.to]]
 * - [[HookMatchCriteria.from]]
 * - [[HookMatchCriteria.exiting]]
 * - [[HookMatchCriteria.retained]]
 * - [[HookMatchCriteria.entering]]
 *
 * A `Glob` string is a pattern which matches state names.
 * Nested state names are split into segments (separated by a dot) when processing.
 * The state named `foo.bar.baz` is split into three segments ['foo', 'bar', 'baz']
 *
 * Globs work according to the following rules:
 *
 * ### Exact match:
 *
 * The glob `'A.B'` matches the state named exactly `'A.B'`.
 *
 * | Glob        |Matches states named|Does not match state named|
 * |:------------|:--------------------|:---------------------|
 * | `'A'`       | `'A'`               | `'B'` , `'A.C'`      |
 * | `'A.B'`     | `'A.B'`             | `'A'` , `'A.B.C'`    |
 * | `'foo'`     | `'foo'`             | `'FOO'` , `'foo.bar'`|
 *
 * ### Single star (`*`)
 *
 * A single star (`*`) is a wildcard that matches exactly one segment.
 *
 * | Glob        |Matches states named  |Does not match state named |
 * |:------------|:---------------------|:--------------------------|
 * | `'*'`       | `'A'` , `'Z'`        | `'A.B'` , `'Z.Y.X'`       |
 * | `'A.*'`     | `'A.B'` , `'A.C'`    | `'A'` , `'A.B.C'`         |
 * | `'A.*.*'`   | `'A.B.C'` , `'A.X.Y'`| `'A'`, `'A.B'` , `'Z.Y.X'`|
 *
 * ### Double star (`**`)
 *
 * A double star (`'**'`) is a wildcard that matches *zero or more segments*
 *
 * | Glob        |Matches states named                           |Does not match state named         |
 * |:------------|:----------------------------------------------|:----------------------------------|
 * | `'**'`      | `'A'` , `'A.B'`, `'Z.Y.X'`                    | (matches all states)              |
 * | `'A.**'`    | `'A'` , `'A.B'` , `'A.C.X'`                   | `'Z.Y.X'`                         |
 * | `'**.X'`    | `'X'` , `'A.X'` , `'Z.Y.X'`                   | `'A'` , `'A.login.Z'`             |
 * | `'A.**.X'`  | `'A.X'` , `'A.B.X'` , `'A.B.C.X'`             | `'A'` , `'A.B.C'`                 |
 *
 */
export class Glob {
  text: string;
  glob: Array<string>;
  regexp: RegExp;

  constructor(text: string) {
    this.text = text;
    this.glob = text.split('.');

    let regexpString = this.text.split('.')
        .map(seg => {
          if (seg === '**') return '(?:|(?:\\.[^.]*)*)';
          if (seg === '*')  return '\\.[^.]*';
          return                   '\\.' + seg;
        }).join('');

    this.regexp = new RegExp("^" + regexpString + "$");
  }

  matches(name: string) {
    return this.regexp.test('.' + name);
  }

  /** @deprecated whats the point? */
  static is(text: string) {
    return text.indexOf('*') > -1;
  }

  /** @deprecated whats the point? */
  static fromString(text: string) {
    if (!this.is(text)) return null;
    return new Glob(text);
  }
}
